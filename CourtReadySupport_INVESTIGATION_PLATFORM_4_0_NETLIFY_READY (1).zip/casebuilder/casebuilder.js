(() => {
'use strict';
const config=window.CASE_APP_CONFIG||{};
const ready=Boolean(window.supabase?.createClient&&config.SUPABASE_URL&&config.SUPABASE_ANON_KEY);
const db=ready?window.supabase.createClient(config.SUPABASE_URL,config.SUPABASE_ANON_KEY):null;
const $=id=>document.getElementById(id);
let session=null,cases=[],activeCase=null,activeItems=[],builderProgress=null,propertyProgress=null,bankProgress=null,isNewCase=false,step=1,propertyStep=1,bankStep=1,investigationProposals=[],intelligenceFilter='all',proposalFilter='all',conversationMessages=[],investigationContext={stage:'initial',topic:'Other',statement:'',date:''};
const totalSteps=5;
const draftBase='crs_casebuilder_draft_v14_';
const sectionNames=['Case identity','People involved','Current position','Court dates','Available material'];
function show(id){$(id).classList.remove('hidden')} function hide(id){$(id).classList.add('hidden')}
function banner(text,type='info'){const e=$('statusBanner');e.textContent=text;e.className=`status-banner show ${type}`}
function clearBanner(){$('statusBanner').className='status-banner'}
function normalise(v){return String(v||'').trim().toLowerCase()}
function draftKey(){return draftBase+(activeCase?.id||'new')}
function setView(view){['authPanel','caseSelectionPanel','caseDashboardPanel','builderPanel','propertyPanel','bankPanel','investigationPanel','successPanel'].forEach(hide);show(view)}
function serialise(){const f=$('caseForm'),d=Object.fromEntries(new FormData(f).entries());d.materials=[...f.querySelectorAll('input[name="materials"]:checked')].map(x=>x.value);return d}
function fill(name,value){const e=$('caseForm').elements.namedItem(name);if(e&&value!==null&&value!==undefined)e.value=value}
function updateStep(){document.querySelectorAll('.form-step').forEach(e=>e.classList.toggle('hidden',Number(e.dataset.step)!==step));document.querySelectorAll('#stepList li').forEach(e=>{const n=Number(e.dataset.step);e.classList.toggle('active',n===step);e.classList.toggle('complete',n<step)});$('progressBar').style.width=`${step/totalSteps*100}%`;$('progressText').textContent=`Step ${step} of ${totalSteps}`;$('previous').classList.toggle('hidden',step===1);$('next').classList.toggle('hidden',step===totalSteps);$('saveCase').classList.toggle('hidden',step!==totalSteps);window.scrollTo({top:0,behavior:'smooth'})}
function validate(){for(const e of document.querySelectorAll(`.form-step[data-step="${step}"] [required]`)){if(!String(e.value||'').trim()){e.reportValidity();return false}}return true}
function saveDraft(showNote=true){localStorage.setItem(draftKey(),JSON.stringify({step,data:serialise(),savedAt:new Date().toISOString()}));if(showNote)$('saveMessage').textContent='Progress saved in this browser.'}
function restoreDraft(){try{const s=JSON.parse(localStorage.getItem(draftKey())||'null');if(!s)return;Object.entries(s.data||{}).forEach(([n,v])=>{if(n==='materials'){document.querySelectorAll('[name="materials"]').forEach(x=>x.checked=(v||[]).includes(x.value))}else fill(n,v)});step=Math.max(1,Math.min(totalSteps,Number(s.step)||1));$('saveMessage').textContent='Saved progress restored.'}catch(e){console.warn(e)}}
async function ensureProfile(){const u=session.user;const {data}=await db.from('profiles').select('id').eq('id',u.id).maybeSingle();if(!data)await db.from('profiles').insert({id:u.id,email:u.email,full_name:'',role:'User',status:'Pending'})}
async function loadCases(){
 $('caseList').innerHTML='';$('casesLoading').textContent='Loading your cases…';show('casesLoading');
 const {data,error}=await db.from('clients').select('*').order('created_at',{ascending:false});
 if(error){$('casesLoading').textContent=`Cases could not be loaded: ${error.message}`;return}
 cases=data||[];hide('casesLoading');renderCases();
}
function renderCases(){const list=$('caseList');list.innerHTML='';if(!cases.length){$('casesLoading').textContent='No cases are currently visible to this account.';show('casesLoading');return}
 cases.forEach(c=>{const card=document.createElement('article');card.className='case-card';const meta=[c.case_type,c.court,c.case_number?`Case ${c.case_number}`:''].filter(Boolean).join(' · ');card.innerHTML=`<div><p class="step-label">${c.stage||'Case record'}</p><h3>${escapeHtml(c.name||'Untitled case')}</h3><p>${escapeHtml(meta||'No further case details recorded')}</p>${c.next_hearing?`<p><strong>Next hearing:</strong> ${escapeHtml(c.next_hearing)}</p>`:''}</div><div class="case-actions"><button class="button primary" type="button">Continue building</button><a class="button secondary" href="https://mckenziecms.co.uk/#dashboard&case=${encodeURIComponent(c.id)}">Full workspace</a></div>`;card.querySelector('button').addEventListener('click',()=>selectCase(c));list.appendChild(card)})}
function escapeHtml(s){return String(s||'').replace(/[&<>'"]/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[m]))}
async function selectCase(c){clearBanner();activeCase=c;isNewCase=false;$('saveModeTitle').textContent='Update this case';$('saveModeText').textContent='Your answers will enrich the selected McKenzieCMS case. They will not create another case.';$('saveCase').textContent='Save to this case';await loadExistingCaseData(c);openDashboard()}
async function loadExistingCaseData(c){$('caseForm').reset();['name','case_type','court','case_number','stage','next_hearing','next_deadline','objective','key_issue'].forEach(n=>fill(n,c[n]||''));fill('background',c.notes||'');
 const {data,error}=await db.from('case_items').select('*').eq('client_id',c.id).order('created_at',{ascending:true});activeItems=error?[]:(data||[]);builderProgress=null;
 const progressRows=activeItems.filter(r=>r.section==='builder'&&r.item?.type==='case_builder_progress');
 if(progressRows.length)builderProgress=progressRows[progressRows.length-1];
 const propertyRows=activeItems.filter(r=>r.section==='builder'&&r.item?.type==='property_housing_module');
 propertyProgress=propertyRows.length?propertyRows[propertyRows.length-1]:null;
 const bankRows=activeItems.filter(r=>r.section==='builder'&&r.item?.type==='bank_funds_module');
 bankProgress=bankRows.length?bankRows[bankRows.length-1]:null;
 for(const r of activeItems){const i=r.item||{};if(r.section==='notes'){const note=i.note||'';if(i.category==='Party details'&&note.startsWith('Applicant:'))fill('applicant_name',note.replace(/^Applicant:\s*/i,''));if(i.category==='Party details'&&note.startsWith('Respondent:'))fill('respondent_name',note.replace(/^Respondent:\s*/i,''));if(i.category==='Party details'&&note.startsWith('Children / dependants:'))fill('children',note.replace(/^Children \/ dependants:\s*/i,''));if(i.category==='Contacts'&&note.startsWith('Representatives / support:'))fill('representatives',note.replace(/^Representatives \/ support:\s*/i,''));}
 if(r.section==='hearings'&&!$('caseForm').elements.namedItem('hearing_type').value){fill('hearing_type',i.hearing||'')}
 if(r.section==='orders'&&!$('caseForm').elements.namedItem('orders').value){fill('orders',i.direction||'')}
 if(r.section==='evidence'){document.querySelectorAll('[name="materials"]').forEach(x=>{if(normalise(i.item||i.type).includes(normalise(x.value)))x.checked=true})}}
 if(propertyProgress?.item?.data)fillPropertyForm(propertyProgress.item.data);
 if(bankProgress?.item?.data)fillBankForm(bankProgress.item.data);
 restoreDraft();
 if(builderProgress?.item?.data){Object.entries(builderProgress.item.data).forEach(([n,v])=>{if(n==='materials'){document.querySelectorAll('[name="materials"]').forEach(x=>x.checked=(v||[]).includes(x.value))}else if(!String($('caseForm').elements.namedItem(n)?.value||'').trim())fill(n,v)});step=Math.max(1,Math.min(totalSteps,Number(builderProgress.item.last_step)||step));}
}
function caseWorkspaceUrl(){return activeCase?.id?`https://mckenziecms.co.uk/#dashboard&case=${encodeURIComponent(activeCase.id)}`:'https://mckenziecms.co.uk/'}
function completionState(data=serialise()){
 const checks=[Boolean(data.name&&data.user_role&&data.case_type),Boolean(data.applicant_name||data.respondent_name||data.children||data.representatives),Boolean(data.background),Boolean(data.next_hearing||data.next_deadline||data.orders),Boolean((data.materials||[]).length||data.other_material)];
 const completed=checks.filter(Boolean).length;return {checks,completed,percent:Math.round(completed/totalSteps*100),next:Math.min(totalSteps,(checks.findIndex(v=>!v)+1)||totalSteps)};
}
function openDashboard(){
 setView('caseDashboardPanel');const d=serialise(),state=completionState(d),meta=[activeCase?.case_type||d.case_type,activeCase?.court||d.court,activeCase?.case_number||d.case_number].filter(Boolean).join(' · ');
 $('dashboardCaseName').textContent=activeCase?.name||d.name||'New case';$('dashboardCaseMeta').textContent=meta||'Complete the missing case details';$('dashboardWorkspaceLink').href=caseWorkspaceUrl();$('dashboardProgressBar').style.width=`${state.percent}%`;$('dashboardProgressText').textContent=`${state.percent}% complete`;
 const saved=builderProgress?.item?.updated_at||builderProgress?.updated_at||builderProgress?.created_at;$('dashboardLastUpdated').textContent=saved?`Last saved ${new Date(saved).toLocaleString('en-GB')}`:'No Case Builder progress saved yet';
 const hearing=d.next_hearing||activeCase?.next_hearing,deadline=d.next_deadline||activeCase?.next_deadline;if(hearing){$('dashboardNextEvent').textContent=`Hearing: ${hearing}`;$('dashboardNextEventDetail').textContent=d.hearing_type||'Hearing type not yet recorded';}else if(deadline){$('dashboardNextEvent').textContent=`Deadline: ${deadline}`;$('dashboardNextEventDetail').textContent=d.deadline_description||'Deadline description not yet recorded';}else{$('dashboardNextEvent').textContent='No hearing or deadline recorded';$('dashboardNextEventDetail').textContent='Add the next court date when known.'}
 const evidenceCount=(d.materials||[]).length+(d.other_material?1:0);$('dashboardEvidenceCount').textContent=`${evidenceCount} categor${evidenceCount===1?'y':'ies'} recorded`;const foundationComplete=state.completed===totalSteps,propertyComplete=Boolean(propertyProgress?.item?.completed),bankComplete=Boolean(bankProgress?.item?.completed);$('dashboardFocus').textContent=!foundationComplete?sectionNames[state.next-1]:!propertyComplete?'Property and Housing':bankComplete?'Investigation Engine':'Bank Accounts and Transferred Funds';$('dashboardFocusDetail').textContent=!foundationComplete?'This is the next incomplete introductory section.':!propertyComplete?'Start the first evidence-led module.':bankComplete?'Review facts, evidence, gaps and issues before publishing them.':'Trace accounts, balances, transfers and missing statements.';$('dashboardNextText').textContent=!foundationComplete?`Continue from ${sectionNames[state.next-1]}.`:!propertyComplete?'Your case foundation is complete. Begin Property and Housing.':bankComplete?'Review Bank Accounts and Funds or prepare for the next module.':'Property and Housing is complete. Continue with the financial trail.';$('continueInterview').textContent=!foundationComplete?'Continue Building My Case':'Investigate My Case';
 const wrap=$('dashboardSections');wrap.innerHTML='';sectionNames.forEach((name,i)=>{const row=document.createElement('button');row.type='button';row.className=`dashboard-section ${state.checks[i]?'complete':'incomplete'}`;row.innerHTML=`<span><strong>${i+1}. ${name}</strong><small>${state.checks[i]?'Complete':'Needs information'}</small></span><span aria-hidden="true">${state.checks[i]?'✓':'→'}</span>`;row.addEventListener('click',()=>{step=i+1;openBuilder()});wrap.appendChild(row)});const propertyRow=document.createElement('button');propertyRow.type='button';propertyRow.className=`dashboard-section ${propertyProgress?.item?.completed?'complete':'incomplete'}`;propertyRow.innerHTML=`<span><strong>6. Property and Housing</strong><small>${propertyProgress?.item?.completed?'Complete':'Detailed module — not started or in progress'}</small></span><span aria-hidden="true">${propertyProgress?.item?.completed?'✓':'→'}</span>`;propertyRow.addEventListener('click',openPropertyModule);wrap.appendChild(propertyRow);const bankRow=document.createElement('button');bankRow.type='button';bankRow.className=`dashboard-section ${bankProgress?.item?.completed?'complete':'incomplete'}`;bankRow.innerHTML=`<span><strong>7. Bank Accounts, Savings and Transferred Funds</strong><small>${bankProgress?.item?.completed?'Complete':'Detailed module — not started or in progress'}</small></span><span aria-hidden="true">${bankProgress?.item?.completed?'✓':'→'}</span>`;bankRow.addEventListener('click',openBankModule);wrap.appendChild(bankRow);const enginePublished=activeItems.some(r=>r.section==='builder'&&r.item?.type==='investigation_publish_batch');const engineRow=document.createElement('button');engineRow.type='button';engineRow.className=`dashboard-section ${enginePublished?'complete':'incomplete'}`;engineRow.innerHTML=`<span><strong>8. Investigation Engine</strong><small>${enginePublished?'Records reviewed and published':'Review facts, evidence, gaps and issues'}</small></span><span aria-hidden="true">${enginePublished?'✓':'→'}</span>`;engineRow.addEventListener('click',openInvestigationEngine);wrap.appendChild(engineRow);
 step=state.next;
}
function openBuilder(){setView('builderPanel');$('activeCaseName').textContent=activeCase?.name||'New case';$('activeCaseMeta').textContent=[activeCase?.case_type,activeCase?.court,activeCase?.case_number].filter(Boolean).join(' · ')||'Complete the missing details';$('builderWorkspaceLink').href=caseWorkspaceUrl();step=step||1;updateStep()}

function makeProposal(type,title,detail,section,item,meta=''){return {id:crypto.randomUUID(),type,title,detail,section,item,meta,selected:true}}
function generateInvestigationProposals(){
 const out=[];const p=propertyProgress?.item?.data||{},b=bankProgress?.item?.data||{};
 if(p.family_home_address||p.other_property_details)out.push(makeProposal('Fact','Relevant property identified',p.family_home_address||p.other_property_details,'facts',{statement:`Relevant property: ${p.family_home_address||p.other_property_details}`,category:'Property',status:'User-reported',source:'investigation-engine-2.0'},'From Property and Housing'));
 if(p.property_evidence)out.push(makeProposal('Evidence','Property evidence available',p.property_evidence,'evidence',{evidenceRef:'CRS-PROPERTY',item:p.property_evidence,type:'Property evidence',source:'Case Builder interview',relevance:'Ownership, value or housing',location:'To be reviewed',sourceSystem:'investigation-engine-2.0'}));
 if(p.property_gaps)out.push(makeProposal('Gap','Property information missing',p.property_gaps,'prep',{task:`Obtain or clarify property evidence: ${p.property_gaps}`,owner:'You',dueDate:'',completed:'No',risk:'Medium',source:'investigation-engine-2.0'}));
 if(p.property_disputes)out.push(makeProposal('Issue','Property issue disputed',p.property_disputes,'issues',{issue:'Property and housing dispute',position:p.property_disputes,status:'Open',source:'investigation-engine-2.0'}));
 if(b.significant_transfers)out.push(makeProposal('Fact','Significant financial transfer identified',b.significant_transfers,'facts',{statement:b.significant_transfers,category:'Financial',status:'User-reported',source:'investigation-engine-2.0'},'From Bank Accounts and Funds'));
 if(b.bank_evidence)out.push(makeProposal('Evidence','Banking evidence available',b.bank_evidence,'evidence',{evidenceRef:'CRS-BANK',item:b.bank_evidence,type:'Financial evidence',source:'Case Builder interview',relevance:'Accounts, balances and transfers',location:'To be reviewed',sourceSystem:'investigation-engine-2.0'}));
 if(b.bank_gaps||b.tracing_required)out.push(makeProposal('Gap','Financial disclosure or tracing required',[b.bank_gaps,b.tracing_required].filter(Boolean).join(' — '),'prep',{task:`Financial evidence gap: ${[b.bank_gaps,b.tracing_required].filter(Boolean).join(' — ')}`,owner:'You',dueDate:'',completed:'No',risk:'High',source:'investigation-engine-2.0'}));
 if(b.bank_disputes||b.transfer_explanation)out.push(makeProposal('Issue','Financial explanation disputed',[b.transfer_explanation,b.bank_disputes].filter(Boolean).join(' — '),'issues',{issue:'Disputed funds or financial explanation',position:[b.transfer_explanation,b.bank_disputes].filter(Boolean).join(' — '),status:'Open',source:'investigation-engine-2.0'}));
 if(b.significant_transfers){const m=b.significant_transfers.match(/(\d{1,2}[\/.-]\d{1,2}[\/.-]\d{2,4}|\d{4}-\d{2}-\d{2})/);if(m)out.push(makeProposal('Chronology','Financial event for chronology',b.significant_transfers,'timeline',{date:m[1],event:b.significant_transfers,category:'Financial',source:'investigation-engine-2.0'}));}
 return out;
}
function proposalCounts(){const c={Fact:0,Evidence:0,Gap:0,Issue:0,Chronology:0};investigationProposals.forEach(p=>c[p.type]=(c[p.type]||0)+1);$('engineFactCount').textContent=c.Fact;$('engineEvidenceCount').textContent=c.Evidence;$('engineGapCount').textContent=c.Gap;$('engineIssueCount').textContent=c.Issue;return c}
function renderProposals(){const list=$('proposalList');list.innerHTML='';proposalCounts();const visible=proposalFilter==='all'?investigationProposals:investigationProposals.filter(p=>p.type===proposalFilter);if(!visible.length)list.innerHTML='<div class="investigation-record empty-working">No working proposals in this category yet.</div>';visible.forEach(p=>{const card=document.createElement('label');card.className=`proposal-card ${p.selected?'selected':''}`;card.innerHTML=`<input type="checkbox" ${p.selected?'checked':''}><div><span class="proposal-type">${escapeHtml(p.type)}</span><h4>${escapeHtml(p.title)}</h4><p>${escapeHtml(p.detail)}</p>${p.meta?`<p class="proposal-meta">${escapeHtml(p.meta)}</p>`:''}</div>`;const cb=card.querySelector('input');cb.addEventListener('change',()=>{p.selected=cb.checked;renderProposals()});list.appendChild(card)});const selected=investigationProposals.filter(p=>p.selected).length;$('publishSelectionCount').textContent=`${selected} selected`;$('reviewSummary').textContent=`${investigationProposals.length} proposed record${investigationProposals.length===1?'':'s'} identified.`;$('publishProposals').disabled=!selected}
function investigationRecordType(record){
 const item=record?.item||{};
 if(record.section==='evidence')return 'evidence';
 if(record.section==='prep')return 'gap';
 if(record.section==='timeline')return 'chronology';
 if(record.section==='notes'&&String(item.method||'').includes('Disputed issue'))return 'issue';
 if(record.section==='notes'&&String(item.method||'').includes('Identified fact'))return 'fact';
 return 'other';
}
function investigationRecordContent(record){
 const item=record?.item||{},type=investigationRecordType(record);
 if(type==='evidence')return {title:item.title||item.type||'Evidence',detail:item.notes||item.relevance||'',meta:[item.date,item.source,item.bundleRef].filter(Boolean).join(' · ')};
 if(type==='gap')return {title:item.task||'Evidence gap',detail:item.notes||'',meta:[item.risk&&`Risk: ${item.risk}`,item.completed&&`Completed: ${item.completed}`].filter(Boolean).join(' · ')};
 if(type==='chronology')return {title:item.event||'Chronology event',detail:item.description||'',meta:[item.date,item.category].filter(Boolean).join(' · ')};
 if(type==='issue')return {title:item.summary||'Disputed issue',detail:item.actionRequired==='Yes'?'Action required':'',meta:[item.date,item.owner].filter(Boolean).join(' · ')};
 return {title:item.summary||'Identified fact',detail:'',meta:[item.date,item.owner].filter(Boolean).join(' · ')};
}
function publishedInvestigationRecords(){return activeItems.filter(r=>['investigation-engine-2.0','investigation-engine-3.0','investigation-engine-4.0'].includes(r.item?.sourceSystem))}
function renderPublishedIntelligence(){
 const records=publishedInvestigationRecords();
 const visible=intelligenceFilter==='all'?records:records.filter(r=>investigationRecordType(r)===intelligenceFilter);
 const list=$('publishedIntelligenceList');if(!list)return;
 $('publishedIntelligenceSummary').textContent=records.length?`${records.length} published Investigation Engine record${records.length===1?'':'s'} are held in this McKenzieCMS case.`:'No Investigation Engine records have been published yet.';
 list.innerHTML='';
 if(!visible.length){list.innerHTML='<div class="empty-state">No published records in this category.</div>';return}
 visible.forEach(record=>{const type=investigationRecordType(record),content=investigationRecordContent(record),card=document.createElement('article');card.className='intelligence-record';card.innerHTML=`<span class="proposal-type">${escapeHtml(type)}</span><h4>${escapeHtml(content.title)}</h4>${content.detail?`<p>${escapeHtml(content.detail)}</p>`:''}${content.meta?`<p class="proposal-meta">${escapeHtml(content.meta)}</p>`:''}`;list.appendChild(card)});
}
function conversationKey(){return `crs_investigation_v3_${activeCase?.id||'new'}`}
function addConversation(role,text,persist=true){conversationMessages.push({role,text,time:new Date().toISOString()});renderConversation();if(persist)localStorage.setItem(conversationKey(),JSON.stringify({messages:conversationMessages,context:investigationContext,proposals:investigationProposals}))}
function renderConversation(){const log=$('conversationLog');if(!log)return;log.innerHTML='';conversationMessages.forEach(m=>{const el=document.createElement('div');el.className=`conversation-message ${m.role}`;el.innerHTML=`<span class="speaker">${m.role==='user'?'You':'CourtReady'}</span>${escapeHtml(m.text)}`;log.appendChild(el)});log.scrollTop=log.scrollHeight}
function inferTopic(text){const t=normalise(text);if(/bank|money|fund|transfer|account|saving|isa|cash|£|pension|income|mortgage/.test(t))return 'Financial';if(/property|house|home|flat|land|valuation|title|poland/.test(t))return 'Property';if(/child|children|son|daughter|school|contact/.test(t))return 'Children';if(/disclos|statement|document|missing|questionnaire/.test(t))return 'Disclosure';if(/hearing|court|order|deadline|judge/.test(t))return 'Procedural';if(/abuse|conduct|threat|alleg/.test(t))return 'Conduct';return 'Other'}
function extractDate(text){const iso=text.match(/\b(20\d{2}-\d{2}-\d{2})\b/);if(iso)return iso[1];const uk=text.match(/\b(\d{1,2})[\/.\-](\d{1,2})[\/.\-](\d{2,4})\b/);if(uk){let y=uk[3];if(y.length===2)y='20'+y;return `${y}-${uk[2].padStart(2,'0')}-${uk[1].padStart(2,'0')}`}return ''}
function addProposalUnique(proposal){const sig=normalise(`${proposal.type}|${proposal.detail}`);if(!investigationProposals.some(p=>normalise(`${p.type}|${p.detail}`)===sig))investigationProposals.push(proposal)}
function setNextQuestion(text){const el=$('nextQuestionText');if(el)el.textContent=text}
function splitMaterialStatements(text){return String(text||'').split(/(?<=[.!?])\s+|\n+/).map(v=>v.trim()).filter(v=>v.length>12).slice(0,8)}
function extractMoney(text){const matches=String(text||'').match(/(?:£|GBP\s*)\s?\d[\d,]*(?:\.\d{1,2})?/gi);return matches?matches.slice(0,5):[]}
function analyseInitialStatement(text){
 const topic=inferTopic(text),date=extractDate(text),statements=splitMaterialStatements(text),money=extractMoney(text);
 investigationContext={stage:'evidence',topic,statement:text,date};
 (statements.length?statements:[text]).forEach((statement,index)=>addProposalUnique(makeProposal('Fact',`${topic} factual proposition${statements.length>1?` ${index+1}`:''}`,statement,'facts',{statement,category:topic,status:'User-reported',source:'investigation-engine-4.0'},date?`Date identified: ${date}`:'Date not yet confirmed')));
 if(date)addProposalUnique(makeProposal('Chronology',`${topic} event`,text,'timeline',{date,event:text,category:topic,source:'investigation-engine-4.0'}));
 money.forEach(amount=>addProposalUnique(makeProposal('Fact','Financial amount identified',`${amount} is mentioned in the account and requires context, ownership and source verification.`,'facts',{statement:`Amount mentioned: ${amount}. Context: ${text}`,category:'Financial',status:'User-reported',source:'investigation-engine-4.0'},'Amount requires tracing and documentary support')));
 const low=normalise(text);
 if(/statement|email|message|whatsapp|letter|order|invoice|valuation|certificate|photo|record|document|form e|bank/.test(low))addProposalUnique(makeProposal('Evidence','Possible supporting material mentioned',text,'evidence',{item:text,type:`${topic} evidence`,source:'User account',relevance:text,sourceSystem:'investigation-engine-4.0'}));
 if(/disput|deny|different|inconsisten|contradict|claims?|alleges?|however|but she|but he/.test(low))addProposalUnique(makeProposal('Issue','Possible disputed or inconsistent point',text,'issues',{issue:text,position:'Requires the competing account and supporting evidence',status:'Open',source:'investigation-engine-4.0'}));
 if(/missing|not provided|no valuation|no statement|unknown|cannot trace|unexplained|not disclosed|never received/.test(low))addProposalUnique(makeProposal('Gap','Possible missing evidence or information',text,'prep',{task:`Clarify or obtain evidence: ${text}`,owner:'You',completed:'No',risk:'Medium',source:'investigation-engine-4.0'}));
 renderProposals();
 const q='What evidence supports this point? Name the document, message, statement, witness or other source. Say “none” if you do not yet have supporting evidence.';
 setNextQuestion(q);addConversation('engine',q)
}
function analyseFollowUp(text){const c=investigationContext,low=normalise(text);if(c.stage==='evidence'){if(!/^(none|no|not yet|unknown)/.test(low)){addProposalUnique(makeProposal('Evidence','Supporting evidence identified',text,'evidence',{item:text,type:`${c.topic} evidence`,source:'User account',relevance:c.statement,sourceSystem:'investigation-engine-4.0'}));setNextQuestion('Is any part of this account disputed, denied, explained differently, or inconsistent with another document?');addConversation('engine','Is any part of this account disputed, denied, explained differently, or inconsistent with another document?')}else{addProposalUnique(makeProposal('Gap','Supporting evidence not yet identified',`No supporting evidence has yet been identified for: ${c.statement}`,'prep',{task:`Identify evidence supporting: ${c.statement}`,owner:'You',completed:'No',risk:'Medium',source:'investigation-engine-4.0'}));setNextQuestion('Is any part of this account disputed, denied, explained differently, or inconsistent with another document?');addConversation('engine','Is any part of this account disputed, denied, explained differently, or inconsistent with another document?')}c.stage='dispute'}else if(c.stage==='dispute'){if(!/^(none|no|not known|unknown)/.test(low))addProposalUnique(makeProposal('Issue','Disputed or inconsistent account',text,'issues',{issue:c.statement,position:text,status:'Open',source:'investigation-engine-4.0'}));c.stage='gap';setNextQuestion('What information or document should exist but is missing, incomplete, outdated or still needs verification?');addConversation('engine','What information or document should exist but is missing, incomplete, outdated or still needs verification?')}else if(c.stage==='gap'){if(!/^(none|no|not known|unknown)/.test(low))addProposalUnique(makeProposal('Gap','Missing evidence or information',text,'prep',{task:`Obtain or clarify: ${text}`,owner:'You',completed:'No',risk:'Medium',source:'investigation-engine-4.0'}));c.stage='complete';setNextQuestion('Review the working propositions, then approve accurate records or investigate another point.');addConversation('engine','This point has been structured for review. Check the investigation board. You can approve accurate records for publication, amend your account, or investigate another point.')}else{analyseInitialStatement(text)}renderProposals();localStorage.setItem(conversationKey(),JSON.stringify({messages:conversationMessages,context:investigationContext,proposals:investigationProposals}))}
function resetInvestigationThread(){conversationMessages=[];investigationContext={stage:'initial',topic:'Other',statement:'',date:''};const q='Tell me your story. Start with one material event, payment, property, document, allegation or missing item.';setNextQuestion(q);addConversation('engine',q);$('conversationInput').focus()}
function restoreInvestigationThread(){try{const saved=JSON.parse(localStorage.getItem(conversationKey())||'null');if(saved){conversationMessages=saved.messages||[];investigationContext=saved.context||investigationContext;const savedProps=saved.proposals||[];savedProps.forEach(addProposalUnique)}if(!conversationMessages.length)resetInvestigationThread();else renderConversation()}catch{resetInvestigationThread()}}
function openInvestigationEngine(){setView('investigationPanel');$('investigationCaseName').textContent=activeCase?.name||'Selected case';$('investigationCaseMeta').textContent=[activeCase?.case_type,activeCase?.court,activeCase?.case_number].filter(Boolean).join(' · ')||'Investigation workspace';$('investigationWorkspaceLink').href=caseWorkspaceUrl();investigationProposals=generateInvestigationProposals();restoreInvestigationThread();renderProposals();renderPublishedIntelligence()}
function startNew(){activeCase={id:null,name:''};activeItems=[];builderProgress=null;propertyProgress=null;bankProgress=null;isNewCase=true;$('caseForm').reset();step=1;$('saveModeTitle').textContent='Create a new McKenzieCMS case';$('saveModeText').textContent='Use this only for a genuinely new matter. A duplicate-name and duplicate-number check will run before creation.';$('saveCase').textContent='Create new case';openBuilder()}
async function duplicateExists(d){let q=db.from('clients').select('id,name,case_number');const {data,error}=await q;if(error)throw error;return (data||[]).find(c=>normalise(c.name)===normalise(d.name)||(d.case_number&&normalise(c.case_number)===normalise(d.case_number)))}
async function persistBuilderProgress(showMessage=true){
 if(!activeCase?.id){saveDraft(showMessage);return}
 const data=serialise(),state=completionState(data),item={type:'case_builder_progress',version:'1.5',last_step:step,completed_sections:state.checks,completion_percent:state.percent,data,updated_at:new Date().toISOString()};
 if(builderProgress?.id){const {data:updated,error}=await db.from('case_items').update({item}).eq('id',builderProgress.id).select().single();if(error)throw error;builderProgress=updated}else{const {data:created,error}=await db.from('case_items').insert({user_id:session.user.id,client_id:activeCase.id,section:'builder',item}).select().single();if(error)throw error;builderProgress=created}
 saveDraft(false);if(showMessage)$('saveMessage').textContent='Progress saved to this case.';
}
function buildItems(d,clientId){const userId=session.user.id,rows=[],add=(section,item)=>rows.push({user_id:userId,client_id:clientId,section,item});const today=new Date().toISOString().slice(0,10);
 if(d.applicant_name)add('notes',{date:today,note:`Applicant: ${d.applicant_name}`,category:'Party details',status:'Recorded',source:'case-builder-1.5'});if(d.respondent_name)add('notes',{date:today,note:`Respondent: ${d.respondent_name}`,category:'Party details',status:'Recorded',source:'case-builder-1.5'});if(d.children)add('notes',{date:today,note:`Children / dependants: ${d.children}`,category:'Party details',status:'Recorded',source:'case-builder-1.5'});if(d.representatives)add('notes',{date:today,note:`Representatives / support: ${d.representatives}`,category:'Contacts',status:'Recorded',source:'case-builder-1.5'});
 add('notes',{date:today,note:`Case Builder 1.4.1 intake. Role: ${d.user_role}. Background: ${d.background}${d.urgent_concern?` Urgent concern: ${d.urgent_concern}`:''}`,category:'Case Builder intake',status:'Recorded',source:'case-builder-1.5'});
 if(d.next_hearing)add('hearings',{date:d.next_hearing,hearing:d.hearing_type||'Hearing',court:d.court||'',nextSteps:'Prepare for hearing',source:'case-builder-1.5'});if(d.next_deadline)add('prep',{task:d.deadline_description||'Court deadline',owner:'You',dueDate:d.next_deadline,completed:'No',risk:'High',source:'case-builder-1.5'});if(d.orders)add('orders',{orderDate:today,direction:d.orders,dueDate:d.next_deadline||'',completed:'No',status:'Open',source:'case-builder-1.5'});(d.materials||[]).forEach((m,n)=>add('evidence',{evidenceRef:`INTAKE-${n+1}`,item:m,type:m,source:'User intake',relevance:'Available — review and link',location:'Not yet uploaded',sourceSystem:'case-builder-1.5'}));if(d.other_material)add('evidence',{evidenceRef:'INTAKE-OTHER',item:d.other_material,type:'Other',source:'User intake',relevance:'Available — review and link',location:'Not yet uploaded',sourceSystem:'case-builder-1.5'});return rows}
async function saveCaseData(d){const payload={user_id:session.user.id,owner_user_id:session.user.id,name:d.name,case_type:d.case_type||null,court:d.court||null,case_number:d.case_number||null,stage:d.stage||null,next_hearing:d.next_hearing||null,next_deadline:d.next_deadline||null,objective:d.objective||null,key_issue:d.key_issue||null,notes:d.background||null,updated_at:new Date().toISOString()};let client;
 if(isNewCase){const dup=await duplicateExists(d);if(dup)throw new Error(`A matching case already exists: ${dup.name}. Return to My Cases and select it instead.`);const {data,error}=await db.from('clients').insert(payload).select().single();if(error)throw error;client=data}else{const {data,error}=await db.from('clients').update(payload).eq('id',activeCase.id).select().single();if(error)throw error;client=data}
 const rows=buildItems(d,client.id);if(rows.length){const {error}=await db.from('case_items').insert(rows);if(error)throw error}return client}
$('next').addEventListener('click',()=>{if(!validate())return;saveDraft(false);step=Math.min(totalSteps,step+1);updateStep()});$('previous').addEventListener('click',()=>{saveDraft(false);step=Math.max(1,step-1);updateStep()});$('saveProgress').addEventListener('click',async()=>{try{await persistBuilderProgress(true)}catch(err){$('saveMessage').textContent=`Progress could not be saved: ${err.message}`}});

function propertySerialise(){return Object.fromEntries(new FormData($('propertyForm')).entries())}
function fillPropertyForm(data){if(!data)return;Object.entries(data).forEach(([name,value])=>{const e=$('propertyForm')?.elements.namedItem(name);if(e&&value!==null&&value!==undefined)e.value=value})}
function propertyCompletion(data=propertySerialise()){const checks=[Boolean(data.family_home_address||data.other_property_details),Boolean(data.registered_owners||data.estimated_value||data.mortgage_balance),Boolean(data.property_evidence||data.property_disputes||data.property_gaps),Boolean(data.user_housing_needs||data.property_outcome||data.property_rationale)];return {checks,percent:Math.round(checks.filter(Boolean).length/4*100),completed:checks.every(Boolean)}}
function updatePropertyStep(){document.querySelectorAll('.property-step').forEach(e=>e.classList.toggle('hidden',Number(e.dataset.propertyStep)!==propertyStep));document.querySelectorAll('#propertyStepList li').forEach(e=>{const n=Number(e.dataset.propertyStep);e.classList.toggle('active',n===propertyStep);e.classList.toggle('complete',n<propertyStep)});$('propertyProgressBar').style.width=`${propertyStep/4*100}%`;$('propertyProgressText').textContent=`Step ${propertyStep} of 4`;$('propertyPrevious').classList.toggle('hidden',propertyStep===1);$('propertyNext').classList.toggle('hidden',propertyStep===4);$('propertySave').classList.toggle('hidden',propertyStep!==4);window.scrollTo({top:0,behavior:'smooth'})}
function openPropertyModule(){setView('propertyPanel');$('propertyCaseName').textContent=activeCase?.name||'Selected case';$('propertyCaseMeta').textContent=[activeCase?.case_type,activeCase?.court,activeCase?.case_number].filter(Boolean).join(' · ')||'Property and housing module';$('propertyWorkspaceLink').href=caseWorkspaceUrl();if(propertyProgress?.item?.data)fillPropertyForm(propertyProgress.item.data);
 if(bankProgress?.item?.data)fillBankForm(bankProgress.item.data);propertyStep=Math.max(1,Math.min(4,Number(propertyProgress?.item?.last_step)||1));updatePropertyStep()}
async function persistPropertyProgress(completed=false){if(!activeCase?.id)throw new Error('Select or create a case before saving this module.');const data=propertySerialise(),state=propertyCompletion(data),item={type:'property_housing_module',version:'1.5',last_step:propertyStep,completion_percent:state.percent,completed:completed||state.completed,data,updated_at:new Date().toISOString()};if(propertyProgress?.id){const {data:updated,error}=await db.from('case_items').update({item}).eq('id',propertyProgress.id).select().single();if(error)throw error;propertyProgress=updated}else{const {data:created,error}=await db.from('case_items').insert({user_id:session.user.id,client_id:activeCase.id,section:'builder',item}).select().single();if(error)throw error;propertyProgress=created}return propertyProgress}
function buildPropertyDerivedItems(data){const rows=[],add=(section,item)=>rows.push({user_id:session.user.id,client_id:activeCase.id,section,item});const today=new Date().toISOString().slice(0,10),propertyName=data.family_home_address||data.other_property_details||'Property and housing';add('assets',{assetType:'Property',description:propertyName,owner:data.registered_owners||'To be confirmed',value:data.estimated_value||'',liability:data.mortgage_balance||'',status:data.beneficial_ownership_disputed==='Yes'?'Disputed':'Recorded',source:'case-builder-1.5'});if(data.property_disputes)add('issues',{issue:'Property and housing dispute',position:data.property_disputes,status:'Open',source:'case-builder-1.5'});if(data.property_gaps)add('prep',{task:`Property evidence gap: ${data.property_gaps}`,owner:'You',dueDate:'',completed:'No',risk:'Medium',source:'case-builder-1.5'});if(data.property_evidence)add('evidence',{evidenceRef:'PROPERTY-MODULE',item:data.property_evidence,type:'Property evidence',source:'User interview',relevance:'Ownership, value or housing issue',location:'To be reviewed',sourceSystem:'case-builder-1.5'});if(data.property_dates)add('timeline',{date:today,event:data.property_dates,category:'Property',source:'case-builder-1.5'});if(data.property_outcome)add('notes',{date:today,note:`Proposed property outcome: ${data.property_outcome}${data.property_rationale?` Rationale: ${data.property_rationale}`:''}`,category:'Property position',status:'Recorded',source:'case-builder-1.5'});return rows}

function bankSerialise(){return Object.fromEntries(new FormData($('bankForm')).entries())}
function fillBankForm(data){if(!data)return;Object.entries(data).forEach(([name,value])=>{const e=$('bankForm')?.elements.namedItem(name);if(e&&value!==null&&value!==undefined)e.value=value})}
function bankCompletion(data=bankSerialise()){const checks=[Boolean(data.joint_accounts||data.user_accounts||data.other_party_accounts||data.savings_investments),Boolean(data.account_balances||data.significant_transfers||data.third_party_funds),Boolean(data.bank_evidence||data.transfer_explanation||data.bank_disputes),Boolean(data.bank_gaps||data.tracing_required||data.funds_outcome||data.funds_rationale)];return {checks,percent:Math.round(checks.filter(Boolean).length/4*100),completed:checks.every(Boolean)}}
function updateBankStep(){document.querySelectorAll('.bank-step').forEach(e=>e.classList.toggle('hidden',Number(e.dataset.bankStep)!==bankStep));document.querySelectorAll('#bankStepList li').forEach(e=>{const n=Number(e.dataset.bankStep);e.classList.toggle('active',n===bankStep);e.classList.toggle('complete',n<bankStep)});$('bankProgressBar').style.width=`${bankStep/4*100}%`;$('bankProgressText').textContent=`Step ${bankStep} of 4`;$('bankPrevious').classList.toggle('hidden',bankStep===1);$('bankNext').classList.toggle('hidden',bankStep===4);$('bankSave').classList.toggle('hidden',bankStep!==4);window.scrollTo({top:0,behavior:'smooth'})}
function openBankModule(){setView('bankPanel');$('bankCaseName').textContent=activeCase?.name||'Selected case';$('bankCaseMeta').textContent=[activeCase?.case_type,activeCase?.court,activeCase?.case_number].filter(Boolean).join(' · ')||'Bank accounts and transferred funds module';$('bankWorkspaceLink').href=caseWorkspaceUrl();if(bankProgress?.item?.data)fillBankForm(bankProgress.item.data);bankStep=Math.max(1,Math.min(4,Number(bankProgress?.item?.last_step)||1));updateBankStep()}
async function persistBankProgress(completed=false){if(!activeCase?.id)throw new Error('Select or create a case before saving this module.');const data=bankSerialise(),state=bankCompletion(data),item={type:'bank_funds_module',version:'1.6',last_step:bankStep,completion_percent:state.percent,completed:completed||state.completed,data,updated_at:new Date().toISOString()};if(bankProgress?.id){const {data:updated,error}=await db.from('case_items').update({item}).eq('id',bankProgress.id).select().single();if(error)throw error;bankProgress=updated}else{const {data:created,error}=await db.from('case_items').insert({user_id:session.user.id,client_id:activeCase.id,section:'builder',item}).select().single();if(error)throw error;bankProgress=created}return bankProgress}
function buildBankDerivedItems(data){const rows=[],add=(section,item)=>rows.push({user_id:session.user.id,client_id:activeCase.id,section,item});const today=new Date().toISOString().slice(0,10);if(data.joint_accounts||data.user_accounts||data.other_party_accounts||data.savings_investments)add('assets',{assetType:'Bank accounts / savings',description:[data.joint_accounts,data.user_accounts,data.other_party_accounts,data.savings_investments].filter(Boolean).join(' | '),owner:'Multiple / to be confirmed',value:data.account_balances||'',liability:'',status:data.bank_disputes?'Disputed':'Recorded',source:'case-builder-1.6'});if(data.significant_transfers)add('timeline',{date:today,event:`Significant transfers identified: ${data.significant_transfers}`,category:'Financial transactions',source:'case-builder-1.6'});if(data.bank_disputes||data.transfer_explanation)add('issues',{issue:'Bank accounts or transferred funds',position:[data.transfer_explanation&&`Explanation: ${data.transfer_explanation}`,data.bank_disputes&&`Dispute: ${data.bank_disputes}`].filter(Boolean).join(' '),status:'Open',source:'case-builder-1.6'});if(data.bank_evidence)add('evidence',{evidenceRef:'BANK-MODULE',item:data.bank_evidence,type:'Bank and transaction evidence',source:'User interview',relevance:'Balances, ownership, transfers and tracing',location:'To be reviewed',sourceSystem:'case-builder-1.6'});if(data.bank_gaps)add('prep',{task:`Bank evidence gap: ${data.bank_gaps}`,owner:'You',dueDate:'',completed:'No',risk:'High',source:'case-builder-1.6'});if(data.tracing_required)add('prep',{task:`Financial tracing required: ${data.tracing_required}`,owner:'You',dueDate:'',completed:'No',risk:'High',source:'case-builder-1.6'});if(data.funds_outcome)add('notes',{date:today,note:`Proposed treatment of funds: ${data.funds_outcome}${data.funds_rationale?` Rationale: ${data.funds_rationale}`:''}`,category:'Financial position',status:'Recorded',source:'case-builder-1.6'});return rows}

async function enterAuthenticatedApp(nextSession){
 session=nextSession;
 if(!session){setView('authPanel');return}
 $('authMessage').textContent='';
 $('signedInIdentity').textContent=`Signed in as ${session.user.email||'your CRS account'}.`;
 setView('caseSelectionPanel');
 try{await ensureProfile()}catch(err){console.warn('Profile check failed:',err)}
 await loadCases();
}
$('signIn').addEventListener('click',async()=>{
 if(!ready)return $('authMessage').textContent='Supabase is not configured.';
 $('signIn').disabled=true;$('authMessage').textContent='Signing in…';
 try{
  const {data,error}=await db.auth.signInWithPassword({email:$('email').value.trim(),password:$('password').value});
  if(error)throw error;
  if(!data?.session)throw new Error('Sign-in succeeded but no session was returned. Please refresh and try again.');
  await enterAuthenticatedApp(data.session);
 }catch(err){$('authMessage').textContent=err.message||'Sign-in failed.'}
 finally{$('signIn').disabled=false}
});
$('signUp').addEventListener('click',async()=>{if(!ready)return $('authMessage').textContent='Supabase is not configured.';const {error}=await db.auth.signUp({email:$('email').value.trim(),password:$('password').value});$('authMessage').textContent=error?error.message:'Account created. Check your email if confirmation is enabled.'});
$('signOut').addEventListener('click',()=>db.auth.signOut());$('continueInterview').addEventListener('click',()=>{const foundation=completionState(serialise()).completed===totalSteps;if(!foundation)openBuilder();else if(!propertyProgress?.item?.completed)openPropertyModule();else if(!bankProgress?.item?.completed)openBankModule();else openInvestigationEngine()});$('dashboardChangeCase').addEventListener('click',async()=>{setView('caseSelectionPanel');await loadCases()});$('newCase').addEventListener('click',startNew);$('newCaseBottom').addEventListener('click',startNew);$('changeCase').addEventListener('click',async()=>{setView('caseSelectionPanel');await loadCases()});$('myCasesNav').addEventListener('click',async e=>{e.preventDefault();if(session){setView('caseSelectionPanel');await loadCases()}});$('returnCases').addEventListener('click',async()=>{setView('caseSelectionPanel');await loadCases()});
$('caseForm').addEventListener('submit',async e=>{
 e.preventDefault();
 if(!validate())return;
 clearBanner();
 $('saveCase').disabled=true;
 $('saveMessage').textContent=isNewCase?'Creating the new case…':'Updating the selected case…';
 try{
  const client=await saveCaseData(serialise());
  activeCase=client;
  isNewCase=false;
  let progressWarning='';
  try{
   await persistBuilderProgress(false);
  }catch(progressError){
   console.warn('Case Builder progress save failed after the main case update:',progressError);
   progressWarning=progressError?.message||'The detailed Case Builder progress record could not be saved.';
  }
  localStorage.removeItem(draftKey());
  await loadExistingCaseData(client);
  openDashboard();
  if(progressWarning){
   banner(`The case was updated, but saved progress needs attention: ${progressWarning}`,'warning');
  }else{
   banner('Your Case Builder information has been saved to this case.','success');
  }
  window.scrollTo({top:0,behavior:'smooth'});
 }catch(err){
  const message=err?.message||'The case could not be saved.';
  banner(message,'error');
  $('saveMessage').textContent=`Save failed: ${message}`;
  window.scrollTo({top:0,behavior:'smooth'});
 }finally{
  $('saveCase').disabled=false;
 }
});

$('propertyPrevious').addEventListener('click',()=>{propertyStep=Math.max(1,propertyStep-1);updatePropertyStep()});
$('propertyNext').addEventListener('click',async()=>{try{await persistPropertyProgress(false);$('propertySaveMessage').textContent='Progress saved.'}catch(err){$('propertySaveMessage').textContent=`Progress could not be saved: ${err.message}`}propertyStep=Math.min(4,propertyStep+1);updatePropertyStep()});
$('propertySaveProgress').addEventListener('click',async()=>{try{await persistPropertyProgress(false);$('propertySaveMessage').textContent='Property and Housing progress saved to this case.'}catch(err){$('propertySaveMessage').textContent=`Progress could not be saved: ${err.message}`}});
$('propertyBackDashboard').addEventListener('click',openDashboard);
$('propertyForm').addEventListener('submit',async e=>{e.preventDefault();$('propertySave').disabled=true;$('propertySaveMessage').textContent='Saving Property and Housing…';try{const data=propertySerialise();await persistPropertyProgress(true);const rows=buildPropertyDerivedItems(data);if(rows.length){const {error}=await db.from('case_items').insert(rows);if(error)throw error}await loadExistingCaseData(activeCase);openDashboard();banner('Property and Housing has been saved. Evidence gaps and disputed points were added to the case workspace.','success')}catch(err){$('propertySaveMessage').textContent=`Save failed: ${err.message}`;banner(err.message||'Property and Housing could not be saved.','error')}finally{$('propertySave').disabled=false}});

$('bankPrevious').addEventListener('click',()=>{bankStep=Math.max(1,bankStep-1);updateBankStep()});
$('bankNext').addEventListener('click',async()=>{try{await persistBankProgress(false);$('bankSaveMessage').textContent='Progress saved.'}catch(err){$('bankSaveMessage').textContent=`Progress could not be saved: ${err.message}`}bankStep=Math.min(4,bankStep+1);updateBankStep()});
$('bankSaveProgress').addEventListener('click',async()=>{try{await persistBankProgress(false);$('bankSaveMessage').textContent='Bank Accounts and Funds progress saved to this case.'}catch(err){$('bankSaveMessage').textContent=`Progress could not be saved: ${err.message}`}});
$('bankBackDashboard').addEventListener('click',openDashboard);
$('investigationBackDashboard').addEventListener('click',openDashboard);
$('conversationForm').addEventListener('submit',e=>{e.preventDefault();const input=$('conversationInput'),text=String(input.value||'').trim();if(!text)return;addConversation('user',text);input.value='';if(investigationContext.stage==='initial'||investigationContext.stage==='complete')analyseInitialStatement(text);else analyseFollowUp(text)});
$('newInvestigationThread').addEventListener('click',resetInvestigationThread);
$('selectAllProposals').addEventListener('click',()=>{investigationProposals.forEach(p=>p.selected=true);renderProposals()});
$('clearProposalSelection').addEventListener('click',()=>{investigationProposals.forEach(p=>p.selected=false);renderProposals()});
document.querySelectorAll('[data-investigation-prompt]').forEach(button=>button.addEventListener('click',()=>{const input=$('conversationInput');input.value=button.dataset.investigationPrompt||'';input.focus()}));
document.querySelectorAll('.finding-tab').forEach(button=>button.addEventListener('click',()=>{proposalFilter=button.dataset.proposalFilter||'all';document.querySelectorAll('[data-investigation-prompt]').forEach(button=>button.addEventListener('click',()=>{const input=$('conversationInput');input.value=button.dataset.investigationPrompt||'';input.focus()}));
document.querySelectorAll('.finding-tab').forEach(b=>b.classList.toggle('active',b===button));renderProposals()}));
$('publishProposals').addEventListener('click',async()=>{const selected=investigationProposals.filter(p=>p.selected);if(!selected.length)return;$('publishProposals').disabled=true;$('investigationMessage').textContent='Publishing approved records…';try{const existingSignatures=new Set(activeItems.filter(r=>['investigation-engine-2.0','investigation-engine-3.0','investigation-engine-4.0'].includes(r.item?.sourceSystem)).map(r=>JSON.stringify([r.section,r.item?.summary||r.item?.title||r.item?.task||r.item?.event||r.item?.notes])));const today=new Date().toISOString().slice(0,10);const toCmsRecord=p=>{const detail=p.detail||'';if(p.type==='Evidence')return {section:'evidence',item:{date:today,title:p.title||'Evidence identified',source:p.item?.source||'CourtReady Case Builder',type:p.item?.type||'Case evidence',relevance:p.item?.relevance||detail,bundleRef:p.item?.evidenceRef||'',notes:detail,sourceSystem:'investigation-engine-4.0'}};if(p.type==='Gap')return {section:'prep',item:{task:p.item?.task||p.title||'Investigate missing evidence',owner:p.item?.owner||'You',dueDate:'',completed:'No',risk:p.item?.risk||'Medium',notes:detail,sourceSystem:'investigation-engine-4.0'}};if(p.type==='Chronology')return {section:'timeline',item:{date:p.item?.date||today,event:p.item?.event||detail,category:p.item?.category||'Other',description:detail,importance:'Medium',sourceSystem:'investigation-engine-4.0'}};if(p.type==='Issue')return {section:'notes',item:{date:today,method:'CourtReady — Disputed issue',summary:detail||p.title,actionRequired:'Yes',owner:'Case owner',deadline:'',completed:'No',sourceSystem:'investigation-engine-4.0'}};return {section:'notes',item:{date:today,method:'CourtReady — Identified fact',summary:detail||p.title,actionRequired:'No',owner:'Case owner',deadline:'',completed:'No',sourceSystem:'investigation-engine-4.0'}}};const rows=[];selected.forEach(p=>{const mapped=toCmsRecord(p),sig=JSON.stringify([mapped.section,mapped.item.summary||mapped.item.title||mapped.item.task||mapped.item.event||mapped.item.notes]);if(!existingSignatures.has(sig))rows.push({user_id:session.user.id,client_id:activeCase.id,section:mapped.section,item:mapped.item})});if(rows.length){const {error}=await db.from('case_items').insert(rows);if(error)throw error}await db.from('case_items').insert({user_id:session.user.id,client_id:activeCase.id,section:'builder',item:{type:'investigation_publish_batch',version:'4.0',published_count:rows.length,reviewed_count:selected.length,published_at:new Date().toISOString()}});await loadExistingCaseData(activeCase);investigationProposals=investigationProposals.filter(p=>!p.selected);localStorage.setItem(conversationKey(),JSON.stringify({messages:conversationMessages,context:investigationContext,proposals:investigationProposals}));renderProposals();renderPublishedIntelligence();banner(`${rows.length} approved record${rows.length===1?' was':'s were'} published to McKenzieCMS.`,'success')}catch(err){$('investigationMessage').textContent=`Publish failed: ${err.message}`;banner(err.message||'Approved records could not be published.','error')}finally{$('publishProposals').disabled=false}});
document.querySelectorAll('.intelligence-tab').forEach(button=>button.addEventListener('click',()=>{intelligenceFilter=button.dataset.intelligenceFilter||'all';document.querySelectorAll('.intelligence-tab').forEach(b=>b.classList.toggle('active',b===button));renderPublishedIntelligence()}));
$('refreshPublishedIntelligence').addEventListener('click',async()=>{try{await loadExistingCaseData(activeCase);renderPublishedIntelligence();$('investigationMessage').textContent='Published McKenzieCMS records refreshed.'}catch(err){$('investigationMessage').textContent=`Refresh failed: ${err.message}`}});
$('bankForm').addEventListener('submit',async e=>{e.preventDefault();$('bankSave').disabled=true;$('bankSaveMessage').textContent='Saving Bank Accounts and Funds…';try{const data=bankSerialise();await persistBankProgress(true);const rows=buildBankDerivedItems(data);if(rows.length){const {error}=await db.from('case_items').insert(rows);if(error)throw error}await loadExistingCaseData(activeCase);openDashboard();banner('Bank Accounts and Transferred Funds has been saved. Financial issues, evidence gaps and tracing tasks were added to the case workspace.','success')}catch(err){$('bankSaveMessage').textContent=`Save failed: ${err.message}`;banner(err.message||'Bank Accounts and Funds could not be saved.','error')}finally{$('bankSave').disabled=false}});

function initialiseSiteHeader(){
 const menuButton=document.querySelector('.menu-button');
 const siteNav=document.getElementById('site-nav');
 if(!menuButton||!siteNav)return;
 menuButton.addEventListener('click',()=>{
  const open=siteNav.classList.toggle('is-open');
  menuButton.setAttribute('aria-expanded',String(open));
 });
 siteNav.querySelectorAll('a').forEach(link=>link.addEventListener('click',()=>{
  siteNav.classList.remove('is-open');
  menuButton.setAttribute('aria-expanded','false');
 }));
}
async function init(){
 initialiseSiteHeader();
 if(!ready){banner('The CMS Supabase configuration or library could not be loaded.','error');setView('authPanel');return}
 const {data,error}=await db.auth.getSession();
 if(error)console.warn('Session check failed:',error);
 if(data?.session)await enterAuthenticatedApp(data.session);else setView('authPanel');
 db.auth.onAuthStateChange((_event,nextSession)=>{
  window.setTimeout(()=>{
   if(nextSession){
    if(!session||session.access_token!==nextSession.access_token)enterAuthenticatedApp(nextSession);
   }else{session=null;setView('authPanel')}
  },0);
 });
 updateStep();
}
init();
})();
